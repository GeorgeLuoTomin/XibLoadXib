//
//  MyXIB.m
//  LAB_XIBloadXIB
//
//  Created by 羅祐昌 on 2016/5/9.
//  Copyright © 2016年 羅祐昌. All rights reserved.
//

#import "MyXIB.h"

@implementation MyXIB

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        //同步 IBOutlet 元件的尺寸，不同步會導致尺寸超出
        self.bounds = CGRectMake(CGRectGetMinX(self.bounds),
                                 CGRectGetMinY(self.bounds),
                                 CGRectGetWidth([UIScreen mainScreen].bounds),
                                 CGRectGetHeight(self.bounds));
        //import XIB
        [[NSBundle mainBundle] loadNibNamed:@"MyXIB" owner:self options:nil];
        [self addSubview:self.view];
        
        //讓 XIB 載入的內容與IBOutlet 元件的尺寸一致
        _view.frame = CGRectMake(0, 0, CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds));
    }
    return self;
}

@end
