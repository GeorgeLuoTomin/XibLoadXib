//
//  MultiFunctionToolBar.h
//  simpleTalk
//
//  Created by 羅祐昌 on 2016/5/5.
//  Copyright © 2016年 Tomin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultiFunctionToolBar : UIView <UITextViewDelegate>
@property (strong, nonatomic) IBOutlet UIView *view;

//@property (weak, nonatomic) IBOutlet UIButton *addAttachmentButton;
//@property (weak, nonatomic) IBOutlet UIButton *addEmojiStickerButton;
//@property (weak, nonatomic) IBOutlet UIButton *sendButton;
//@property (weak, nonatomic) IBOutlet UITextView *textView;
//@property (weak, nonatomic, readwrite) id target;

@end
