//
//  ViewController.m
//  LAB_XIBloadXIB
//
//  Created by 羅祐昌 on 2016/5/6.
//  Copyright © 2016年 羅祐昌. All rights reserved.
//

#import "ViewController.h"
#import "MyXIB.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet MyXIB *myXIBview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.myXIBview.layer.borderWidth = 3;
    self.myXIBview.layer.borderColor = [UIColor greenColor].CGColor;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
