//
//  MultiFunctionToolBar.m
//  simpleTalk
//
//  Created by 羅祐昌 on 2016/5/5.
//  Copyright © 2016年 Tomin. All rights reserved.
//

#import "MultiFunctionToolBar.h"

@implementation MultiFunctionToolBar
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //同步 IBOutlet 元件的尺寸，不同步會導致尺寸超出
        self.bounds = CGRectMake(0,
                                 0,
                                 CGRectGetWidth([UIScreen mainScreen].bounds),
                                 CGRectGetHeight(self.bounds));
        
        //import XIB
        [[NSBundle mainBundle] loadNibNamed:@"MultiFunctionToolBar" owner:self options:nil];
        [self addSubview:_view];
        
        //讓 XIB 載入的內容與IBOutlet 元件的尺寸一致
        _view.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
        
        [self multiFunctionToolBarStyle:self];
        
        
    }
    return self;
}


#pragma mark - set up
- (void)multiFunctionToolBarStyle:(UIView *)multiFunctionToolBar {
    self.layer.mask = [self maskViewWithTargetView:self];
    self.layer.masksToBounds = YES;
}

#pragma mark - tool
- (CALayer *)maskViewWithTargetView:(UIView *)targetView {
    CGFloat leadMargin = 14;
    UIView *maskView = [[UIView alloc] initWithFrame:CGRectMake(leadMargin,
                                                                0,
                                                                CGRectGetWidth(targetView.frame) - (leadMargin * 2) ,
                                                                CGRectGetHeight(targetView.frame))];
    maskView.backgroundColor = [UIColor redColor];
    maskView.layer.cornerRadius = CGRectGetHeight(maskView.frame) / 2;
    maskView.clipsToBounds = YES;
    maskView.layer.masksToBounds = YES;
    
    return maskView.layer;
}

#pragma mark - button action
- (IBAction)addAttachmentButtonAction:(UIButton *)sender forEvent:(UIEvent *)event {
    NSLog(@"addAttachmentButtonAction");
}

- (IBAction)addEmojiStickerButtonAction:(UIButton *)sender forEvent:(UIEvent *)event {
    NSLog(@"addEmojiStickerButtonAction");
}

- (IBAction)sendButtonAction:(UIButton *)sender forEvent:(UIEvent *)event {
    NSLog(@"sendButtonAction");
}

#pragma mark - UITextViewDelegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    NSLog(@"textViewShouldBeginEditing");
    
    return YES;
}

@end
