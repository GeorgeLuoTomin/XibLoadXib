//
//  main.m
//  LAB_XIBloadXIB
//
//  Created by 羅祐昌 on 2016/5/6.
//  Copyright © 2016年 羅祐昌. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
