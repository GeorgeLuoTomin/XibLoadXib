//
//  ViewController.h
//  LAB_XIBloadXIB
//
//  Created by 羅祐昌 on 2016/5/6.
//  Copyright © 2016年 羅祐昌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

